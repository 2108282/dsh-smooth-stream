# dsh-smooth-stream

> **让 AI 的长篇生成如提词器般温润流淌。**  
> 为 DeepSeek Harness（`dsh`）打造的二阶弹簧物理流式渲染与零重排跟随引擎。

[English](README.en.md) · [项目主页](https://laplace-bit.github.io/dsh-smooth-stream/) · [工作原理与基准](https://laplace-bit.github.io/dsh-smooth-stream/how-it-works.html) · [npm](https://www.npmjs.com/package/dsh-smooth-stream)

---

## 极致丝滑的阅读手感

无论是阅读数百行的长篇推演，还是紧盯高速吐字的代码生成，`dsh-smooth-stream` 带来的是一种**沉浸、连贯且零视觉负担**的阅读质感：

- **如水流般自然铺展**：告别大段文本突然“砸”在屏幕上的视觉压迫，字句如打字机般富有呼吸感地逐字涌现；
- **视线无需追赶跳动**：视口如同搭载了高精度阻尼滑轨，随文字增长平稳匀速推移，彻底终结换行时的突发踢移；
- **呼吸感与实时性的平衡**：慢速输出时从容优雅，高并发爆发时平稳追赶，无论模型吐字多快，画面始终从容自若。

---

## 为什么需要它？

大模型输出是通过网络分块到达的。一个数据包可能在几毫秒内送达数百字符，下一个分块却需要数十毫秒。

如果直接将 DOM 渲染和视口滚动绑定在离散的到达事件上，通常会引发两个阅读体验问题：
1. **视觉跳跃与撕裂**：段落、代码块和表格整段突发呈现，视线被迫频繁重新寻焦；
2. **滚动抖动与重排风暴**：依靠 `scrollTop = scrollHeight` 进行瞬时硬跳；即使用 CSS `scroll-behavior: smooth`，高频写入也会不断重置缓动曲线，导致动画永远无法收敛，高速流下伴随剧烈的主线程重排。

`dsh-smooth-stream` 将**内容呈现**与**视口运动**拆分为两个独立的物理状态机，在每一帧动画回调（rAF）中连续积分，彻底消除跳跃感。

---

## 核心机理与架构

```
[ 模型 SSE 分块流 ]
         │
         ▼
 ┌─────────────────┐       背压阻尼 (0.55x ~ 1.0x)       ┌─────────────────┐
 │   揭示节奏引擎   │ ◄──────────────────────────────── │   弹簧跟随引擎   │
 │ (Reveal Engine) │                                   │ (Follow Engine) │
 └────────┬────────┘                                   └────────┬────────┘
          │ 字符积压与分数积分                                      │ 二阶阻尼弹簧积分 (k=130, c=24)
          ▼                                                     ▼
 [ 逐帧平滑展开 DOM ] ───────────────────────────────► [ 合成层 Transform 补偿 ]
  (单帧视觉位移 ≤ 8px)                                   (0 Reflow / 纯 GPU 合成)
```

### 1. 动态自适应的揭示引擎（Reveal Engine）
- **分数级字符积分**：根据积压队列深度自适应调节速度（$v = 90 + \text{backlog}^{1.25} \times P$），低负载时从容自然，高积压时平稳追赶，绝不倾泻整段文本。
- **折行限幅平滑**：长文本和代码块发生换行时，单帧视觉位移被限制在 8px 以内，将原本 24~28px 的单帧跳跃平摊至数帧完成。
- **尾部平稳收束**：回合结束标记到达后，残余缓冲区以恒定速率释放，正文、思考链与工具调用之间自然衔接。

### 2. 纯合成层驱动的跟随引擎（Follow Engine）
- **二阶阻尼物理系统**：采用 $k=130, c=24, m=1$ 的亚步进物理弹簧，将内容高度的变化转化为平滑连续的速度与位移轨迹。
- **零重排（Zero-Reflow）位移补偿**：真实滚动容器始终锚定在底部，剩余的视觉滞后完全由外层 DOM 的 `transform: translate3d` 吸收。跟随过程不读写任何触发 Layout 的属性，杜绝重排风暴。
- **闭环背压控制（Closed-Loop Backpressure）**：当跟随滞后接近预留空间时，反向向揭示引擎施加阻尼（最低降至 0.55 倍速），防止文本增长超出视口弹簧范围。
- **掉帧自愈与跨刷新率一致**：主线程卡顿（Stall）时自动钳位物理时间（$\le 32\text{ms}$），避免画面恢复后的突进瞬移；在 60Hz 与 120Hz（ProMotion）屏幕下拥有近乎一致的物理收敛时间。

### 3. 会话生命周期自动折叠（Turn Auto-Collapse）
- 对话进行时，思考链与工具调用保持实时展开；
- 回合结算完成并稳定后，自动将执行过程收敛为一行极简的 `已处理 X 秒` 摘要，保持工作区专注；支持随时点击无缝展开。

### 4. 响应式严格串行接力架构（Reactive Baton Relay Queue）

大模型在处理复杂推演与多步 Agent 循环时，其输出通常经历三个明确阶段：**思考链（Reasoning） → 前置正文回复（Response Text） → 工具调用与执行（Tool Execution）**。

在 DeepSeek Harness 底层架构中，上述三个部分分别被挂载为互相独立的 React 树实例。若任由各组件自发展开，在大模型突发数据包下会发生**三者并发展开、互相抢占屏幕焦点、引发剧烈 DOM 重排和手机卡顿发烫**的问题。

`dsh-smooth-stream` 引入了响应式**接力棒调度中枢（Stream Relay）**，实现跨组件生命周期的严格有序接力：

```
[ 模型生成流 ]
      │
      ▼
┌────────────────────────────────────────────────────────┐
│  Phase 1: 思考链平滑展开 (Reasoning Stream)              │
│  - 思考过程优雅吐字与对数淡入                             │
│  - 正文与工具节点处于挂起状态 (0 CPU 消耗)                 │
│  - 结束标记到达后缓冲区匀速泄压，自动折叠并交出接力棒       │
└───────────────────────────┬────────────────────────────┘
                            │ 接力交接
                            ▼
┌────────────────────────────────────────────────────────┐
│  Phase 2: 前置正文流式输出 (Text Response Stream)         │
│  - 从第 0 个字符开始流畅呼吸吐字                           │
│  - 二阶弹簧平稳跟随，杜绝突变硬跳                         │
│  - 期间锁定工具调用状态，工具节点平稳等待                   │
│  - 全部正文完成物理收束后，释放工具锁                     │
└───────────────────────────┬────────────────────────────┘
                            │ 释放锁
                            ▼
┌────────────────────────────────────────────────────────┐
│  Phase 3: 工具调用执行与入场 (Tool Execution & Entrance)  │
│  - 工具卡片解除锁定，120ms GPU 硬件加速平滑淡入           │
│  - 工具执行、状态更新与结果卡片展开                       │
│  - 零 DOM 丢失，零阅读焦点跳动                            │
└────────────────────────────────────────────────────────┘
```

- **零 DOM 轮询开销（Zero-Polling Architecture）**：彻底剔除传统 `MutationObserver` 祖先/兄弟遍历的高开销方案，基于 React 18 的 `useSyncExternalStore` 订阅轻量原子状态机，内存级毫秒响应，保障移动端在长篇大回复下始终维持 60/120fps 满帧运行。
- **视觉呼吸感与时序一致性**：无论模型是以超高突发速度倾泻 Token，还是在慢速推演，画面永远保持「思考结束才开始正文、正文读完才弹出工具」的人类阅读心智模型。

### 5. 对话状态栏与底座分割线防抖隔离（Running Status & Baseline Stabilization）
- **精准适配 DSH 原生运行状态容器**：通过 `[data-chat-running]` 与选择器层级回溯，精准识别 Harness 官方底部状态栏（含「深度求索中…」指示器与底部分割线 `runningDivider`），将其从常规消息变换表面（`shiftSurfaces`）中完全隔离。
- **换行轨迹平滑同步推进**：在换行高度激增（`floorNow > trajectoryFloorPx`）瞬间，同步推进物理轨迹位置 `trajectoryPositionPx`，保持视觉位移 `shiftPx` 的绝对连续，彻底终结了“吐字折行时整行被强行向上拉高”的风琴式抽搐。
- **剔除工具/命令步骤交替时的虚假高度叠加**：移除将状态栏瞬态高度 `lastStatusHeightPx` 粗暴累加进预留跑道 `reservePx` 的逻辑，彻底解决“一出现调用工具或使用命令底部就被剧烈拉高、随后缓慢回落”的瞬态突起。
- **跑道物理偏移量严格钳位**：限制 `ensureRunway` 的 offset 不得超过实际跑道尺寸上限，防止文本并发折行高度泄漏污染跑道，使底座分割线和状态栏在全生命周期始终如磐石般稳定锚定在视口底部。

---

## 效果对比

左：默认 Web UI。右：dsh-smooth-stream。

![左：未使用插件。右：使用 dsh-smooth-stream。](docs/compare.gif)

---

## 性能与基准

平滑度与稳定性基于本地自动化审计台架验证：

| 验证闸门 | 测试项目 | 指标要求 |
| :--- | :--- | :--- |
| **流式渲染审计** | `node scripts/run-render-audit.mjs` | 5 种典型生成场景下 10/10 Clean，零位移回退 |
| **视口溢出闸门** | `node scripts/verify-overflow.mjs` | 极限输出场景下零过滚、零反弹 |
| **尾行晃动抑制** | `pnpm test` | 单帧跳变 ≤30px，7 帧振幅峰值 ≤32px |

- 核心 ESM 产物经 Gzip 压缩后仅约 **4.7 kB**。详见[工作原理与基准](https://laplace-bit.github.io/dsh-smooth-stream/how-it-works.html)。

---

## 安装与使用

在 DeepSeek Harness 源码根目录运行：

```sh
pnpm dsh plugin --profile web add dsh-smooth-stream
```

如果系统 `PATH` 中已有 `dsh`：

```sh
dsh plugin --profile web add dsh-smooth-stream
```

启动界面：

```sh
pnpm dsh web
```

Host 日志中显示 `[dsh-smooth-stream] plugin loaded!` 即表示已成功加载。

不联网构建时，可直接安装仓库里已构建好的安装包（见 [`dist/`](dist/README.md)）：

```sh
npm install https://raw.githubusercontent.com/2108282/dsh-smooth-stream/main/dist/dsh-smooth-stream-0.9.0.tgz
```

装进 DSH profile 时先下载再用本地路径：

```sh
curl -L -O https://raw.githubusercontent.com/2108282/dsh-smooth-stream/main/dist/dsh-smooth-stream-0.9.0.tgz
pnpm dsh plugin --profile web add /绝对路径/dsh-smooth-stream-0.9.0.tgz
```

卸载命令：`pnpm dsh plugin --profile web remove dsh-smooth-stream`。

---

## 内核兼容性

| DSH 内核 | 本插件支持情况 |
|---|---|
| `0.2.2-rc.2` | ✅ 已迁移并验证新版 `ui-conversation` / `ui-chat` slot 与 renderer 契约 |
| `0.1.x` | ❌ 此版本线现已结束支持；请使用 `0.1.x` 兼容发行版 |

- ✅ = 兼容。当前适配基于 `0.2.2-rc.2` 的 `@deepseek-ai/dsh-client-ui-renderer`、`ui-conversation` 和 `ui-chat`。
- `0.2.2-rc.2` 起助手文本通过包装官方 keyed renderer 平滑呈现；官方 renderer 仍拥有 locale、turn-process hooks、图片/思考子 slots、上下文菜单及其余交互。
- Fast pipeline 是独立的可选优化，仅拦截 `animation-frame` publication；关闭插件或设置时保留官方三帧行为。
- **不要对 `@deepseek-ai/*` 包的运行时符号做静态导入**。宿主 CLI 经 `node --import tsx/esm` 启动，tsx 会应用宿主 `tsconfig` 的 `paths` 映射，外部插件对 `@deepseek-ai/*` 的裸导入可能被重定向进宿主源码，一旦宿主侧改名/删符号就会以模块实例化错误的形式炸掉启动。类型导入（`import type`）不受影响。

## 配置与手感预设

插件默认采用 `preset: balanced`。如需切换手感，可在对应 profile 的 `cordis.patch.yml` 中修改：

| `preset` | 动态特性 |
| :--- | :--- |
| `realtime` | 紧跟模型分块到达节奏，缓冲更小 |
| `balanced` | 默认推荐，兼顾阅读流畅度与响应延迟 |
| `silky` | 增大缓冲区，追赶更平缓柔和 |

---

## 用户偏好设置

在 Web 界面打开 **设置 → 插件 → 插件配置**，可对 **丝滑流式（Smooth stream）** 卡片进行个性化调节：

- **启用丝滑流式渲染**（默认开启）：接管回复和工具行的渲染与跟随；关闭后即时恢复 Harness 内置渲染。
- **自动展开思考**：使用官方 disclosure Hook，在推理流式生成时展开，排空后收起；保留用户手动选择及官方 Turn reset。
- **工具引导语保持流式**：开启后等前置正文真正排空再呈现工具；关闭则即时交接。接力按 Session、Turn、Step 隔离，中断或卸载释放自己的队列。
- **接管滚动**：在新版分组结构上平滑跟随，读者向上滚动后让出控制，完成时回收预留空间。
- **对数淡入**（默认开启）：回答正文和展开的思考内容中，尾部范围随输出速度从 24 扩展到最多 160 个字素，从 0% 不透明度在 240ms 内按反向对数曲线变实（前段更通透，后段变实）。网络停顿时也会恢复清晰；关闭此项保留逐字输出与滚动。遵循动效偏好，跳过代码、公式和思考摘要，不支持文字范围着色的浏览器自动使用原有输出效果。
- **完成后自动折叠**（默认开启）：回合处理完成后，将思考过程与工具调用折叠为摘要行。
- **显示渲染调试面板**（默认关闭）：在界面右侧开启实时 HUD，观测 FPS、字符积压、弹性曲线并微调物理参数。

本地淡入预览：执行 `pnpm build:repro`，在仓库根目录启动 `python3 -m http.server 8765 --bind 127.0.0.1`，打开 `http://127.0.0.1:8765/repro/index.html?demo=fade`。预览包含暂停、停止、深浅主题、高速分片和代码/公式保护样例，复用真实输出引擎，富文本为测试样例。

执行 `node scripts/verify-logarithmic-fade.mjs` 可验证并录制预览（需要 Chrome 和 `pnpm exec playwright-core install ffmpeg`；其他 Chrome 路径可用 `CHROME_BIN` 指定），报告与视频保存在未跟踪的 `repro/artifacts/logarithmic-fade/`。

---

## 许可证

[MIT](LICENSE)
